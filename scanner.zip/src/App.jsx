import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wifi, WifiOff, Loader2 } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { useQrCodeData } from '@/hooks/useQrCodeData';
import { HomeScreen } from '@/components/screens/HomeScreen';
import { ScannerScreen } from '@/components/screens/ScannerScreen';
import { DisplayScreen } from '@/components/screens/DisplayScreen';
import supabaseRealtimeService from '@/services/supabaseRealtimeService';

function App() {
  const [mode, setMode] = useState('home'); // 'home', 'scanner', 'display'
  const { currentCode, lastUpdate, isConnected, updateCodeInSupabase, fetchInitialCode } = useQrCodeData();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // The useQrCodeData hook now handles its own initialization via the service
    // We just need to manage the global loading state
    const initializeApp = async () => {
      setIsLoading(true);
      // fetchInitialCode is now more of a getter or a way to ensure service is up
      // The actual data fetching and listener setup is in useQrCodeData's useEffect
      // which calls supabaseRealtimeService.initialize
      await fetchInitialCode(); // This call might be redundant if service handles all initial state
      setIsLoading(false); 
    };
    initializeApp();

    // Global cleanup for the service when App unmounts
    return () => {
      supabaseRealtimeService.cleanup();
    };
  }, [fetchInitialCode]); // fetchInitialCode is stable from useCallback

  const handleModeChange = (newMode) => {
    setMode(newMode);
  };

  // Show loading indicator until the service confirms connection OR initial data is fetched
   useEffect(() => {
    if (!isConnected && currentCode === '') { // Still waiting for initial load / connection
      setIsLoading(true);
    } else {
      setIsLoading(false);
    }
  }, [isConnected, currentCode]);


  if (isLoading) {
    return (
      <div className="min-h-screen gradient-bg flex flex-col items-center justify-center text-white">
        <Loader2 className="w-16 h-16 animate-spin mb-4 text-blue-300" />
        <p className="text-xl">Chargement de l'application...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-bg">
      <div className="container mx-auto px-4 py-6 max-w-md">
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl font-bold text-white mb-2">QR Scanner</h1>
          <div className="flex items-center justify-center gap-2 text-white/80">
            {isConnected ? (
              <>
                <Wifi className="w-4 h-4 text-green-400" />
                <span className="text-sm">Connecté à Supabase</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-red-400" />
                <span className="text-sm">Déconnecté</span>
              </>
            )}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {mode === 'home' && (
            <HomeScreen 
              onModeChange={handleModeChange}
              currentCode={currentCode}
              lastUpdate={lastUpdate}
            />
          )}
          {mode === 'scanner' && (
            <ScannerScreen 
              onModeChange={handleModeChange}
              currentCode={currentCode}
              lastUpdate={lastUpdate}
              updateCodeInSupabase={updateCodeInSupabase}
              fetchInitialCode={fetchInitialCode}
            />
          )}
          {mode === 'display' && (
            <DisplayScreen 
              onModeChange={handleModeChange}
              currentCode={currentCode}
              lastUpdate={lastUpdate}
            />
          )}
        </AnimatePresence>
      </div>
      <Toaster />
    </div>
  );
}

export default App;